# StreamUFSC

Sistema desktop para organizar e avaliar filmes e séries, desenvolvido em C++17 com Qt Widgets. Projeto final (T2) da disciplina **Linguagem de Programação 2**, da Universidade Federal de Santa Catarina (UFSC), Campus Araranguá.

## Descrição do trabalho

O StreamUFSC resolve o problema de registrar títulos que a pessoa quer assistir, está assistindo ou já assistiu. A aplicação reúne um catálogo visual de filmes e séries, uma coleção pessoal, filtros, pesquisa, avaliações e persistência local.

A coleção começa vazia: nenhum título é marcado como favorito ou recebe nota sem ação da usuária. O catálogo incluído no projeto contém 34 títulos com pôsteres; cada título pode ser adicionado à coleção e avaliado depois.

## Funcionalidades

- Tela inicial com entrada pelo botão ou pela tecla Enter.
- Catálogo com 34 pôsteres e visualização de detalhes de cada título.
- Cadastro de filmes e séries, com gênero, ano, tipo, status e pôster opcional.
- Ações para adicionar à coleção, favoritar, avaliar de 0 a 5, alterar o status e remover títulos.
- Filtros por todos, favoritos, quero assistir, assistindo, assistidos e catálogo.
- Pesquisa por título, gênero, ano ou tipo e filtro entre filmes e séries.
- Grade de pôsteres que se adapta à largura da janela.
- Salvamento automático da coleção em arquivo de texto na pasta de dados do usuário.

## Requisitos do T2 demonstrados

- **C++ e orientação a objetos:** classe `Movie` encapsula os dados de cada título; as janelas separam as responsabilidades da interface.
- **Qt Creator e interface gráfica:** projeto com Qt Widgets e formulários `.ui` editáveis no Qt Designer.
- **Quatro janelas:** tela inicial, janela principal, cadastro de filme/série e janela “Sobre o desenvolvedor”.
- **Componentes variados:** o formulário usa `QLineEdit`, `QComboBox`, `QSpinBox`, `QLabel` e `QPushButton`.
- **Persistência:** a coleção é carregada na abertura e salva quando é alterada.

A janela “Sobre” contém a foto e o nome completo da desenvolvedora. A matrícula foi omitida nesta cópia destinada à publicação pública; se a versão entregue à disciplina precisar desse dado, ele pode ser acrescentado localmente antes de entregar o ZIP ao docente.

## Apresentação do T2

O enunciado do trabalho pede um vídeo de até 8 minutos contendo uma breve descrição do problema, a demonstração de partes importantes do código e a execução do programa. Os slides são opcionais. O projeto Qt Creator deve ser enviado em arquivo ZIP.

## Como abrir e executar

### Qt Creator

1. Abra `StreamUFSC.pro` no Qt Creator.
2. Selecione um kit Qt para desktop e configure o projeto.
3. Execute pelo botão **Run** ou por `Ctrl+R`.

### CMake

O `CMakeLists.txt` procura Qt 6 ou Qt 5 com o módulo Widgets:

```bash
cmake -S . -B build
cmake --build build
```

No Windows, execute `build/StreamUFSC.exe` (ou o executável dentro da pasta de configuração gerada pelo CMake). No Linux/macOS, execute `./build/StreamUFSC`.

## Persistência dos dados

A coleção é salva em `dados_filmes.txt` dentro da pasta de dados do usuário. O arquivo usa um registro por linha com os campos título, gênero, ano, tipo, status, nota, favorito e caminho do pôster. Formatos antigos separados por `|` também são reconhecidos.

Os pôsteres do catálogo são recursos do projeto e não são gravados na coleção até serem adicionados. Imagens escolhidas no cadastro são copiadas para a pasta de dados do aplicativo, para que continuem disponíveis se o arquivo original for movido.

## Estrutura

```text
main.cpp                         inicialização da aplicação
movie.h / movie.cpp              modelo de filme ou série
theme.h / theme.cpp              paleta e estilos visuais
startwindow.*                    tela inicial
mainwindow.*                     catálogo, coleção, pesquisa e filtros
addmoviewindow.*                 cadastro de títulos
aboutwindow.*                    informações da desenvolvedora
resources.qrc                    pôsteres e imagem da tela inicial
images/                          recursos visuais do projeto
```

## Licença

Projeto distribuído sob a licença MIT. Consulte [LICENSE](LICENSE).
